function blkStruct = slblocks
  % Specify that the product should appear in the library browser
  % and be cached in its repository
  Browser.Library = 'jailib';
  Browser.Name    = 'Power Library';
  blkStruct.Browser = Browser;
